
export type Page = 'Boutique' | 'Headphones' | 'Speakers' | 'Earphones' | 'ProductYX1' | 'ProductXX59' | 'ProductXX99Mark1' | 'ProductXX99Mark2' | 'ProductZX7' | 'ProductZX9' | 'BigShop' | 'CartPage';


