<script setup lang="ts">

</script>

<template>
  <div class="title d-flex justify-content-center align-items-center">
      <h2 class="text-4xl">EARPHONES</h2>
  </div>
  
</template>

<style lang="scss" scoped>

.title {
    height: 14vh;
    background-color: var(--black-1);
    color: var(--white-1);
}
</style>
